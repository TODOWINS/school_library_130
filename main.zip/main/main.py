import mysql.connector
import tkinter as tk
from tkinter import messagebox, Label, Entry, Button
from tkinter import *

def show_admin_ui():

    window0.destroy()
    # Function to execute the query and get the total number of loans per school
    def get_loan_counts():
        try:
            # Retrieve the year and month values from the input fields
            year = int(year_entry.get())
            month = int(month_entry.get())

            # Establish a connection to the MariaDB database
            cnx = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="school_library"
            )

            # Create a cursor object to interact with the database
            cursor = cnx.cursor()

            # Construct the query to get the total number of loans per school
            query = """
                SELECT su.School_Name, COUNT(l.Loan_ID) AS Loan_Count
                FROM School_Units su
                LEFT JOIN Users u ON su.School_Unit_ID = u.School_Unit_ID
                LEFT JOIN Loan l ON u.User_ID = l.User_ID AND YEAR(l.Loan_Date) = %s AND MONTH(l.Loan_Date) = %s
                GROUP BY su.School_Name
            """

            # Execute the query with the provided search criteria
            cursor.execute(query, (year, month))

            # Fetch all rows from the resultset
            rows = cursor.fetchall()

            # Clear the result text widget
            result_text.delete("1.0", tk.END)

            # Display the total number of loans per school in the result text widget
            result_text.insert(tk.END, f"Schools And How Many Books they have Loaned the Selected Month:\n")
            i = 1
            for row in rows:
                school_name, loan_count = row
                result_text.insert(tk.END, f"{i}.{school_name},Total Loans: {loan_count}\n")
                i += 1

            # Close the cursor and the database connection
            cursor.close()
            cnx.close()

        except mysql.connector.Error as err:
            messagebox.showerror("Error", f"Error executing query: {err}")

    def get_authors():
        try:
            # Retrieve the selected book category from the dropdown menu
            selected_category = category_var.get()

            # Establish a connection to the MariaDB database
            cnx = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="school_library"
            )

            # Create a cursor object to interact with the database
            cursor = cnx.cursor()

            # Construct the query to get the authors and teachers for the selected book category
            query = """
                SELECT CONCAT(authors.First_Name ,' ', authors.Last_Name) AS Full_Name
                FROM authors
                JOIN book_author as b ON authors.Author_ID = b.Author_ID
                JOIN books as bk ON b.Book_ID = bk.Book_ID
                JOIN book_category as bc ON bk.Book_ID = bc.Book_ID
                JOIN category as c ON bc.Category_ID = c.Category_ID
                WHERE c.Category_Name = %s;
            """

            # Execute the query with the selected book category
            cursor.execute(query, (selected_category,))

            # Fetch all rows from the resultset
            rows = cursor.fetchall()

            # Clear the result text widget
            result_text.delete("1.0", tk.END)

            # Display the authors and teachers in the result text widget
            result_text.insert(tk.END, f"Authors that have written a book in the selected Category:\n")
            i = 1
            for row in rows:
                First_Name = row
                result_text.insert(tk.INSERT, f"{i}.{First_Name[0]}\n")
                i += 1

            # Close the cursor and the database connection
            cursor.close()
            cnx.close()

        except mysql.connector.Error as err:
            messagebox.showerror("Error", f"Error executing query: {err}")

    def get_teachers():
        try:
            # Retrieve the selected book category from the dropdown menu
            selected_category2 = clicked.get()

            # Establish a connection to the MariaDB database

            cnx2 = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="school_library"
            )

            # Create a cursor object to interact with the database
            cursor2 = cnx2.cursor()
            # Construct the query to get the authors and teachers for the selected book category
            query2 = '''
                SELECT DISTINCT u.First_Name, u.Last_Name
                FROM users as u
                JOIN loan as l ON u.User_ID = l.User_ID
                JOIN books as b ON l.Book_ID = b.Book_ID
                JOIN book_category as bc ON b.Book_ID = bc.Book_ID
                JOIN category as c ON bc.Category_ID = c.Category_ID
                WHERE c.Category_Name = %s AND l.Loan_Date >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR) AND u.Roles = 'Teacher'
                '''

            # Execute the query with the selected book category
            cursor2.execute(query2, (selected_category2,))

            # Fetch all rows from the resultset
            rows2 = cursor2.fetchall()

            # Clear the result text widget
            result_text2.delete("1.0", tk.END)

            # Display the authors and teachers in the result text widget
            result_text2.insert(tk.END, f"Teachers that have rent a book from the selected Category :\n")
            i = 1
            for row2 in rows2:
                FN = row2
                result_text2.insert(tk.INSERT, f"{i}.{FN[0]}\n")
                i += 1

            # Close the cursor and the database connection
            cursor2.close()
            cnx2.close()

        except mysql.connector.Error as err:
            messagebox.showerror("Error", f"Error executing query: {err}")

    def get_maxbooks():
        try:

            cnx3 = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="school_library"
            )
            cursor3 = cnx3.cursor()
            # Construct the query to get the authors and teachers for the selected book category
            query3 = """
                SELECT DISTINCT CONCAT(users.First_Name,' ', users.Last_Name) AS Full_Name, COUNT(*) AS Borrowed_Books
                FROM users 
                JOIN loan ON users.User_ID = loan.User_ID
                WHERE users.Age < 40 AND users.Roles = 'Teacher'
                GROUP BY users.First_Name , users.Last_Name
                HAVING COUNT(*) = (
                  SELECT MAX(Num_Borrowed)
                  FROM (
                    SELECT COUNT(*) AS Num_Borrowed
                    FROM users 
                    JOIN loan ON users.User_ID = loan.User_ID
                    WHERE users.Roles = 'Teacher' AND users.Age < 40
                    GROUP BY users.User_ID
                  )AS T
                );
            """

            # Execute the query with the selected book category
            cursor3.execute(query3)

            # Fetch all rows from the resultset
            rows3 = cursor3.fetchall()

            result_text3.delete("1.0", tk.END)

            # Display the authors and teachers in the result text widget
            result_text3.insert(tk.END, f"Teachers || Number of Books:\n")
            i = 1

            if rows3:
                for row3 in rows3:
                    for i in range(0, 2):
                        full_name = row3
                        result_text3.insert(tk.END, f"{full_name[i]}")
                        if i != 1:
                            result_text3.insert(tk.END, f":")

                    result_text3.insert(tk.END, f"\n")
            else:
                result_text3["text"] = "No young teachers found."

            # Close the cursor and the database connection
            cursor3.close()
            cnx3.close()

        except mysql.connector.Error as err:
            messagebox.showerror("Error", f"Error executing query: {err}")

    def get_noloans():
        try:

            cnx4 = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="school_library"
            )

            cursor4 = cnx4.cursor()
            # Construct the query to get the authors and teachers for the selected book category
            query4 = """
                SELECT DISTINCT authors.Author_ID, authors.First_Name, authors.Last_Name
                FROM school_library.authors
                LEFT JOIN school_library.book_author ON authors.Author_ID = book_author.Author_ID
                LEFT JOIN school_library.books ON book_author.Book_ID = books.Book_ID
                LEFT JOIN school_library.loan ON books.Book_ID = loan.Book_ID
                WHERE book_author.Book_ID NOT IN (
                SELECT loan.Book_ID
                FROM school_library.loan
                )
                ;
            """

            # Execute the query with the selected book category
            cursor4.execute(query4)

            # Fetch all rows from the resultset
            rows4 = cursor4.fetchall()

            result_text4.delete("1.0", tk.END)

            # Display the authors and teachers in the result text widget
            result_text4.insert(tk.END, f"Authors whose books have not been borrowed.\n"
                                        f"Author_ID | Author Name\n")

            if rows4:
                for row4 in rows4:
                    for i in range(0, 2):
                        full_name = row4
                        result_text4.insert(tk.END, f"{full_name[i]}")
                        if i != 1:
                            result_text4.insert(tk.END, f"  \t    ")

                    result_text4.insert(tk.END, f"\n")
            else:
                result_text4["text"] = "All authors have their books borrowed.\n"

            # Close the cursor and the database connection
            cursor4.close()
            cnx4.close()

        except mysql.connector.Error as err:
            messagebox.showerror("Error", f"Error executing query: {err}")

    def get_op():
        try:

            cnx5 = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="school_library"
            )

            cursor5 = cnx5.cursor()
            # Construct the query to get the authors and teachers for the selected book category
            query5 = """
                SELECT users.First_Name, users.Last_Name
                FROM users 
                JOIN school_units ON users.School_Unit_ID = school_units.School_Unit_ID
                WHERE users.Roles = 'School_Admin' AND
                school_units.School_Unit_ID IN (
                    SELECT users.School_Unit_ID
                    FROM users 
                    JOIN loan ON users.User_ID = loan.User_ID
                    WHERE users.Roles IN ('Teacher', 'Student')
                    GROUP BY users.School_Unit_ID
                    HAVING COUNT(loan.User_ID) > 20
                    AND COUNT(loan.User_ID) = ANY (
                      SELECT COUNT(loan.User_ID)
                      FROM loan
                      JOIN users ON loan.User_ID = users.User_ID
                      WHERE users.Roles = 'Teacher' OR users.Roles = 'Student'
                      GROUP BY users.School_Unit_ID
                      HAVING COUNT(loan.User_ID) > 20
                   )
                );
            """

            # Execute the query with the selected book category
            cursor5.execute(query5)

            # Fetch all rows from the resultset
            rows5 = cursor5.fetchall()

            result_text5.delete("1.0", tk.END)

            # Display the authors and teachers in the result text widget
            result_text5.insert(tk.END, f"School Admins with more than 20 and equal number of loans:\n")

            if rows5:
                for row5 in rows5:
                    for i in range(0,2):
                        if(i != 1):
                            result_text5.insert(tk.END, f"School Admin name: ")
                        full_name = row5
                        result_text5.insert(tk.END, f"{full_name[i]}")

                        if(i != 1):
                            result_text5.insert(tk.END, f" ")
                        else:
                            result_text5.insert(tk.END, f"\n")


            else:
                result_text5.insert(tk.END, f"No school admins found!\n")

            # Close the cursor and the database connection
            cursor5.close()
            cnx5.close()

        except mysql.connector.Error as err:
            messagebox.showerror("Error", f"Error executing query: {err}")

    window = tk.Tk()
    window3 = tk.Tk()
    window4 = tk.Tk()
    window.title("ADMIN PANEL: Loan Counts per School")
    window.geometry("1000x600")

    window3.title("ADMIN PANEL: Maximum No of Books Query")
    window3.geometry("1000x600")

    window4.title("ADMIN PANEL: Authors Whose Books Have no Loans,and School Admins with more than 20 Loans")
    window4.geometry("1000x600")

    result_text5 = tk.Text(window4)
    result_text5.pack()
    year_label = tk.Label(window, text="Year:")
    year_label.pack()
    year_entry = tk.Entry(window)
    year_entry.pack()

    month_label = tk.Label(window, text="Month:")
    month_label.pack()
    month_entry = tk.Entry(window)
    month_entry.pack()

    # Create the button to execute the query
    query_button = tk.Button(window, text="Get Loan Counts", command=get_loan_counts)
    query_button.pack()
    # Create the input field and label for book category
    category_label = tk.Label(window, text="Book Category:")
    category_label.pack()
    category_var = tk.StringVar()
    category_dropdown = tk.OptionMenu(window, category_var, "Fiction", "Non-Fiction", "Romance", "Sci-fi", "Biography")
    category_dropdown.pack()

    # Create the button to execute the query
    tkobj = tk
    query_button = tk.Button(window, text="Get Authors and Teachers", command=get_authors)
    query_button.pack()
    category_label = tk.Label(window3, text="Second Book Category:")
    category_label.pack()
    clicked = tk.StringVar()
    clicked.set("Fiction")
    category_dropdown = tk.OptionMenu(window3, clicked, "Fiction", "Non-Fiction", "Romance", "Sci-fi", "Biography")
    category_dropdown.pack()
    query_button1 = tk.Button(window3, text="Get Teachers who have rented from Selected Category", command=get_teachers)
    query_button1.pack()

    query_button3 = tk.Button(window3, text="Get Maximum No of Books Rented By Young Teachers", command=get_maxbooks)
    query_button3.pack()

    query_button4 = tk.Button(window4, text="Get the Authors with Zero Loans", command=get_noloans)


    query_button5 = tk.Button(window4,text="Get the School Admins who loaned more than 20 times the same number of books in a year",command=get_op)
    query_button5.pack()
    query_button4.pack()
    result_text = tk.Text(window)
    result_text.pack()

    result_text2 = tk.Text(window3)
    result_text2.pack()

    result_text3 = tk.Text(window3)
    result_text3.pack()

    result_text4 = tk.Text(window4)
    result_text4.pack()
    window.mainloop()


def show_sa_ui():

    window0.destroy()

    def search_books():

        try:


            conn = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="school_library"
            )

            cursor = conn.cursor()
            querySa = """
                        SELECT b.Title,a.First_Name,a.Last_Name
                        FROM books as b
                        JOIN book_author as ba ON b.Book_ID = ba.Book_ID
                        JOIN authors as a ON ba.Author_ID = a.Author_ID
                        """
            cursor.execute(querySa)



            # Fetch all the rows returned by the query
            rows = cursor.fetchall()

            # Display the results in the GUI
            result_text6.delete(1.0, tk.END)
            if rows:
                for row in rows:
                    result_text6.insert(tk.END, f"Title: {row[0]}\nAuthor: {row[1]} {row[2]}\n\n")
            else:
                result_text6.insert(tk.END, "No books found.")

            cursor.close()
            conn.close()


        except mysql.connector.Error as err:
            messagebox.showerror("Error", f"Error executing query: {err}")

    def search_books2():
        title2 = title_entry.get()
        category2 = category_entry.get()
        author2 = author_entry.get()

        try:


            conn = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="school_library"
            )
            cursor2 = conn.cursor()
            querySa2 = """
                                            SELECT b.Title, a.First_Name,a.Last_Name
                                            FROM books as b
                                            JOIN book_author as ba ON b.Book_ID = ba.Book_ID 
                                            JOIN authors as a ON ba.Author_ID = a.Author_ID 
                                            JOIN book_category as bc ON b.Book_ID = bc.Book_ID
                                            JOIN category as c ON bc.Category_ID = c.Category_ID
                                            WHERE b.Title LIKE %s AND c.Category_Name LIKE %s AND a.First_Name LIKE %s       
                                            """
            cursor2.execute(querySa2, (f"%{title2}%", f"%{category2}%", f"%{author2}%"))

            # Fetch all the rows returned by the query
            rows2 = cursor2.fetchall()

            # Display the results in the GUI
            result_text6.delete(1.0, tk.END)
            if rows2:
                for row in rows2:
                    result_text6.insert(tk.END, f"Title: {row[0]}\nAuthor: {row[1]} {row[2]}\n\n")
            else:
                result_text6.insert(tk.END, "No books found.")

            cursor2.close()
            conn.close()

        except mysql.connector.Error as err:
            messagebox.showerror("Error", f"Error executing query: {err}")

    windows5 = tk.Tk()
    windows5.title("Book Search")
    windows5.geometry("1000x1000")

    title_label = tk.Label(windows5, text="Title:")
    title_label.pack()
    title_entry = tk.Entry(windows5)
    title_entry.pack()

    category_label = tk.Label(windows5, text="Category:")
    category_label.pack()
    category_entry = tk.Entry(windows5)
    category_entry = tk.StringVar()
    category_dropdown = tk.OptionMenu(windows5, category_entry, "Fiction", "Non-Fiction", "Romance", "Sci-fi","Biography")
    category_dropdown.pack()

    author_label = tk.Label(windows5, text="Author:")
    author_label.pack()
    author_entry = tk.Entry(windows5)
    author_entry.pack()

    result_text6 = tk.Text(windows5)
    result_text6.pack()
    search_button = Button(windows5, text="Find All.", command=search_books)
    search_button2 = Button(windows5, text="Find based on Criteria.", command=search_books2)
    search_button.pack()
    search_button2.pack()

def show_user_ui():

    window0.destroy()

    def get_avail_books():
        try:
            conn = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="school_library"
            )

            cursor = conn.cursor()
            queryUs = f"""
                        SELECT DISTINCT books.Title,authors.First_Name,authors.Last_Name,books.Available_Copies
                        FROM books 
                        JOIN book_author ON books.Book_ID = book_author.Book_ID
                        JOIN authors ON book_author.Author_ID = authors.Author_ID
                        INNER JOIN users ON books.School_Unit_ID = users.School_Unit_ID
                        JOIN school_units ON users.School_Unit_ID = school_units.School_Unit_ID
                        JOIN loan ON books.Book_ID = loan.Book_ID
                        WHERE loan.Due_Date NOT IN (DATE_SUB(CURDATE(), INTERVAL 7 DAY)) 
                            AND users.User_ID LIKE {id} 
                            AND books.School_Unit_ID = school_units.School_Unit_ID
                        GROUP BY books.School_Unit_ID, books.Title, authors.First_Name, authors.Last_Name, books.Available_Copies
                    """

            cursor.execute(queryUs)

            # Fetch all the rows returned by the query
            rows = cursor.fetchall()

            # Display the results in the GUI
            result_text7.delete(1.0, tk.END)
            if rows:
                for row in rows:
                    result_text7.insert(tk.END, f"Title: {row[0]}\nAuthor: {row[1]} {row[2]}\nAvailable Copies: {row[3]}\n\n")
            else:
                result_text7.insert(tk.END, "No books found.")

            # Create a label for the book selection
            label_selection = tk.Label(windows6, text="Select a book:")
            label_selection.pack()

            # Create an entry for the book selection
            entry_selection = tk.Entry(windows6)
            entry_selection.pack()
#
#     Η create_reservation() δεν ειναι ολοκληρωμενη
#
            def create_reservation():

                title3 = title_entry3.get()

                # Define the query to create a reservation request
                queryCreateReservation = f"""
                    INSERT INTO Reservations (Reservation_ID,Reservation_Date, Expiration_Date, User_ID, Book_ID)
                    SELECT CURDATE(), DATE_ADD(CURDATE(), INTERVAL 7 DAY), users.User_ID, books.Book_ID
                    FROM books 
                    JOIN users ON books.School_Unit_ID = users.School_Unit_ID
                    WHERE books.Title LIKE %s AND users.User_ID LIKE {id} 
                """

                # Replace <User_ID> with the actual ID of the logged-in user


                # Execute the query to create a reservation request
                cursor.execute(queryCreateReservation, title3)

                # Commit the changes to the database
                conn.commit()

                # Show a confirmation message
                tk.messagebox.showinfo("Reservation", "Reservation request created successfully.")

                # Clear the entry field
                entry_selection.delete(0,tk.END)

            button_reserve = tk.Button(windows6, text="Reserve", command=create_reservation)
            button_reserve.pack()

            windows6.mainloop()
            cursor.close()
            conn.close()



        except mysql.connector.Error as err:
            messagebox.showerror("Error", f"Error executing query: {err}")


    windows6 = tk.Tk()
    windows6.title("User Panel")
    windows6.geometry("700x700")
    title_entry3 = tk.Entry(windows6)
    result_text7 = tk.Text(windows6)
    search_button3 = Button(windows6, text="List the available books : ", command=get_avail_books)
    search_button3.pack()

    result_text7.pack()


# Function to start the program and ask for login details
def get_login():

    try:

        global Login_Name
        # Retrieve the user and password values from the input fields
        Login_Name = user_entry.get()
        password = pass_entry.get()
        #id_entry = tk.getint()
        #id = id_entry.get()

        # Establish a connection to the mySQL database
        cnx0 = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="school_library"
        )

        # Create a cursor object to interact with the database
        cursor0 = cnx0.cursor()

        # Construct the query to get the total number of loans per school
        query0 = f"""
            SELECT Roles,User_ID FROM Users WHERE Username = %s AND Password = %s
        """

        # Execute the query with the provided search criteria
        cursor0.execute(query0,(Login_Name, password))
        # Fetch all rows from the resultset
        result = cursor0.fetchone()
        global id
        id = result[1]
        if result is not None:
            role = result[0]

            if role == 'Central_Admin':
                show_admin_ui()
            elif role == 'School_Admin':
                show_sa_ui()
            elif role == 'Student' or 'Teacher':
                show_user_ui()
            else:
                print('You are not authorized to access this interface.')
        else:
            # User credentials are incorrect
            messagebox.showerror('Login Failed', 'Invalid username or password')

        # Close the cursor and the database connection
        cursor0.close()
        cnx0.close()

    except mysql.connector.Error as err:
        messagebox.showerror("Error", f"Error executing query0: {err}")
    finally:
        cursor0.close()
        cnx0.close()
        print('MySQL connection closed')



window0 = tk.Tk()
window0.title('Login')
window0.geometry('300x150')

username_label = tk.Label(window0, text='Username:')
username_label.pack()
user_entry = tk.Entry(window0)
user_entry.pack()

password_label= tk.Label(window0, text='Password:')
password_label.pack()
pass_entry = tk.Entry(window0, show='*')
pass_entry.pack()

button_login = tk.Button(window0, text='Login', command=get_login)
button_login.pack()


window0.mainloop()







